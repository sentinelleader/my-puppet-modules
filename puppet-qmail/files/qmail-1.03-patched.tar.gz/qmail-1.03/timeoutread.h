#ifndef TIMEOUTREAD_H
#define TIMEOUTREAD_H

extern int timeoutread(int, int, char *, int);

#endif
