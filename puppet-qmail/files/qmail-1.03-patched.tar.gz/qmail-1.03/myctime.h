#ifndef MYCTIME_H
#define MYCTIME_H

#include "datetime.h"

extern char *myctime(datetime_sec);

#endif
