#ifndef GFROM_H
#define GFROM_H

extern int gfrom(char *, int);

#endif
