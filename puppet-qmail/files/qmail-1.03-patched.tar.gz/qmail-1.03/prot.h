#ifndef PROT_H
#define PROT_H

extern int prot_gid(unsigned int);
extern int prot_uid(unsigned int);

#endif
