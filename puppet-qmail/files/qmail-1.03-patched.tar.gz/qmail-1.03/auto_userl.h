#ifndef AUTO_USERL_H
#define AUTO_USERL_H

extern char auto_userl[];

#endif
