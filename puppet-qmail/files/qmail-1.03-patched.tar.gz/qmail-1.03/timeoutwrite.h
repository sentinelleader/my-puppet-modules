#ifndef TIMEOUTWRITE_H
#define TIMEOUTWRITE_H

extern int timeoutwrite(int, int, const void *, int);

#endif
