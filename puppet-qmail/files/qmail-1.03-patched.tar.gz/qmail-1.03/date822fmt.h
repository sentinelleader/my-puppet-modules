#ifndef DATE822FMT_H
#define DATE822FMT_H

#include "datetime.h"

extern unsigned int date822fmt(char *, struct datetime *);
#define DATE822FMT 60

#endif
