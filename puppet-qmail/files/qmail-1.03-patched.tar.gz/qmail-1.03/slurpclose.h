#ifndef SLURPCLOSE_H
#define SLURPCLOSE_H

#include "stralloc.h"

extern int slurpclose(int, stralloc *, unsigned int);

#endif
