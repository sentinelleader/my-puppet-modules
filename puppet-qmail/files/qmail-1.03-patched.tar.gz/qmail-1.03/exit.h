#ifndef EXIT_H
#define EXIT_H

/* XXX unistd.h */
extern void _exit(int);

#endif
