#ifndef AUTO_PATRN_H
#define AUTO_PATRN_H

extern unsigned int auto_patrn;

#endif
