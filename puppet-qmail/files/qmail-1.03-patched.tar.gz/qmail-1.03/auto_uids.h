#ifndef AUTO_UIDS_H
#define AUTO_UIDS_H

extern unsigned int auto_uida;
extern unsigned int auto_uidd;
extern unsigned int auto_uidl;
extern unsigned int auto_uido;
extern unsigned int auto_uidp;
extern unsigned int auto_uidq;
extern unsigned int auto_uidr;
extern unsigned int auto_uids;

extern unsigned int auto_gidn;
extern unsigned int auto_gidq;

#endif
