#ifndef AUTO_SPLIT_H
#define AUTO_SPLIT_H

extern unsigned int auto_split;

#endif
