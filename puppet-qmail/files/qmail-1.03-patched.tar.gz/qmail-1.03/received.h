#ifndef RECEIVED_H
#define RECEIVED_H

#include "qmail.h"

extern void received(struct qmail *, const char *, const char *, const char *,
    const char *, const char *, const char *, const char *, const char *);

#endif
