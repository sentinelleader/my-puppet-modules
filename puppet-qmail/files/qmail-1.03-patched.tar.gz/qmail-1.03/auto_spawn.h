#ifndef AUTO_SPAWN_H
#define AUTO_SPAWN_H

extern unsigned int auto_spawn;

#endif
