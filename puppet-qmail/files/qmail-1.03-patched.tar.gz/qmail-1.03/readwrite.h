#ifndef READWRITE_H
#define READWRITE_H

int subread(int, void *, int);
int subwrite(int, void *, int);

#endif
