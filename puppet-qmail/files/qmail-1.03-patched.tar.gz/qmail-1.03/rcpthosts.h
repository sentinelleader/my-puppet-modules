#ifndef RCPTHOSTS_H
#define RCPTHOSTS_H

extern int rcpthosts_init(void);
extern int rcpthosts(char *, unsigned int);
extern int localhosts(char *, unsigned int);

#endif
